package com.example.randomize

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.randomize.databinding.ActivityMainBinding
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {
    private var random: Int = 0
    private var startText = "Guess My Number"
    private var count: Int = 4
    private var guess: Int = 0
    private var isFinished = false
    private var successful = false

    private lateinit var binding : ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //To Show life Level
        binding.lifeLevel.text = count.toString()

        //To Start Game
        Snackbar.make(binding.holder, "Click to Start",
            Snackbar.LENGTH_INDEFINITE)
            .setAction("Start") { isFinished = randomize()}.show()

        //To Restart Activity
        binding.resetButton.setOnClickListener{
            val intent = intent
            finish()
            startActivity(intent)
        }
    }

    private fun randomize(): Boolean{
        val range = 1..100
        random = range.random()
        binding.welcome.text = startText
        binding.computerPick.text = "**"
        Snackbar.make(binding.holder, "A Range of 1 to 100", 3000)
            .show()
        val setRandom = binding.floatingActionButton
        setRandom.setOnClickListener{ isFinished = calculate()}
        return isFinished
    }

    private fun calculate(): Boolean {
        val enteredGuess: String = binding.enteredGuess.text.toString()
        if (enteredGuess == "" || enteredGuess == "0"){
            Snackbar.make(binding.holder, "Enter a valid guess", 3000)
                .show()
            count--
            binding.lifeLevel.text = count.toString()
        } else {
            guess = enteredGuess.toInt()
            when {
                guess<random -> {
                    Snackbar.make(binding.holder, "Too low, try Again!", 3000)
                        .show()
                    count--
                    binding.lifeLevel.text = count.toString()
                }
                guess>random -> {
                    Snackbar.make(binding.holder, "Too high, try Again", 3000)
                        .show()
                    count--
                    binding.lifeLevel.text = count.toString()
                }
                else -> {
                    Snackbar.make(binding.holder, "CONGRATULATIONS!!", 2000)
                        .show()
                    binding.computerPick.text = random.toString()
                    successful = true
                    return true
                }
            }
        }

        return true
    }
}